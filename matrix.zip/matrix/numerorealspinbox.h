#ifndef NUMEROREALSPINBOX_H
#define NUMEROREALSPINBOX_H


class NumeroRealSpinBox
{
public:
    NumeroRealSpinBox();
};

#endif // NUMEROREALSPINBOX_H
