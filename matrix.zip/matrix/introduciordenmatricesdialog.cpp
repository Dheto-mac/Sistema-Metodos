#include "introduciordenmatricesdialog.h"
#include "ui_introduciordenmatricesdialog.h"

IntroduciOrdenMatricesDialog::IntroduciOrdenMatricesDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::IntroduciOrdenMatricesDialog)
{
    ui->setupUi(this);
    setWindowTitle("Orden de las matrices");
    ui->numeroDeFilasSpinBox->setMinimum(1);
    ui->numeroDeFilasSpinBox->setMaximum(INT_MAX);
    ui->numeroDeColumnasSpinBox->setMinimum(1);
    ui->numeroDeColumnasSpinBox->setMaximum(INT_MAX);

}

IntroduciOrdenMatricesDialog::~IntroduciOrdenMatricesDialog()
{
    delete ui;
}

int IntroduciOrdenMatricesDialog::getNumeroDeFilas() const
{
    return ui->numeroDeFilasSpinBox->value();
}

int IntroduciOrdenMatricesDialog::getNumeroDeColumnas() const
{
    return ui->numeroDeColumnasSpinBox->value();
}

void IntroduciOrdenMatricesDialog::on_buttonBox_accepted()
{
    accept();
}

void IntroduciOrdenMatricesDialog::on_buttonBox_rejected()
{
    reject();
}
