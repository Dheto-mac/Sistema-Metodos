#ifndef INTRODUCIORDENMATRICESDIALOG_H
#define INTRODUCIORDENMATRICESDIALOG_H

#include <QDialog>

namespace Ui
{
class IntroduciOrdenMatricesDialog;
}

class IntroduciOrdenMatricesDialog : public QDialog
{
    Q_OBJECT

public:
    explicit IntroduciOrdenMatricesDialog(QWidget *parent = nullptr);
    ~IntroduciOrdenMatricesDialog();
    int getNumeroDeFilas()const;
    int getNumeroDeColumnas()const;

private slots:
    void on_buttonBox_accepted();
    void on_buttonBox_rejected();
private:
    Ui::IntroduciOrdenMatricesDialog *ui;
};

#endif // INTRODUCIORDENMATRICESDIALOG_H
