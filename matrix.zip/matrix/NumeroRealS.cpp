#include "numerorealspinbox.h"

NumeroRealSpinBox::NumeroRealSpinBox()
{

}
