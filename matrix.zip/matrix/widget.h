#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE
class QStandardItemModel;
class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_Quitar_app_pushButton_clicked();
    void on_introducirMatrices_PushButton_clicked();
    void on_sumaMatrices_PushButton_clicked();

private:
    double getValueAt(QStandardItemModel *model,int fila,int col)const;
    Ui::Widget *ui;
    QStandardItemModel *mModelA;
    QStandardItemModel *mModelB;
    QStandardItemModel *mModelResultado;
};
#endif // WIDGET_H
